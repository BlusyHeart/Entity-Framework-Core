﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trucks.Common
{
    public class ValidationConstants
    {
        public const int MAX_REGISTRATION_NUMBER = 8;

        public const int MAX_LENGTH_VIN_NUMBER = 17;
    }
}
